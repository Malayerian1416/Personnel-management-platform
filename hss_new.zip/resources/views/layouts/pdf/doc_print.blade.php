    <style>
        @font-face {
            font-family: 'Iransans';
            font-style: normal;
            font-weight: normal;
            src: url({{ asset('/fonts/Iransans.ttf') }}) format('truetype');
        }
        @font-face {
            font-family: 'Iranyekan';
            font-style: normal;
            font-weight: normal;
            src: url({{ asset('/fonts/Iranyekan.ttf') }}) format('truetype');
        }
        @font-face {
            font-family: 'Mitra';
            font-style: normal;
            font-weight: normal;
            src: url({{ asset('/fonts/Mitra.ttf') }}) format('truetype');
        }
        @font-face {
            font-family: 'Nastaliq';
            font-style: normal;
            font-weight: normal;
            src: url({{ asset('/fonts/Nastaliq.ttf') }}) format('truetype');
        }
        @font-face {
            font-family: 'Nazanin';
            font-style: normal;
            font-weight: normal;
            src: url({{ asset('/fonts/Nazanin.ttf') }}) format('truetype');
        }
        @font-face {
            font-family: 'Titr';
            font-style: normal;
            font-weight: normal;
            src: url({{ asset('/fonts/Titr.ttf') }}) format('truetype');
        }
        @page {
            background: url() no-repeat 0 0;
        }
        body{
            direction: rtl;
            font-family: 'Titr','sans-serif';

        }
        .sd{
            position: absolute;
            font-size: 25px;
            top: 80px;
            right: 150px;
        }
    </style>
<body>
    <p class="sd">مسعود ملایریان</p>
</body>
