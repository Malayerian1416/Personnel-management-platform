<table style="direction: rtl">
    <thead>
    <tr>
        <th style="color: #ffffff;background-color: #343A40">
            کد ملی پرسنل
            <strong style="color: red">*</strong>
        </th>
        <th style="color: #ffffff;background-color: #343A40">
            تاریخ شروع(مثلا 1400/01/01)
            <strong style="color: red">*</strong>
        </th>
        <th style="color: #ffffff;background-color: #343A40">
            تاریخ پایان(مثلا 1400/05/31)
            <strong style="color: red">*</strong>
        </th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
