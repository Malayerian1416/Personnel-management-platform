<table style="direction: rtl">
    <thead>
    <tr>
        <th style="color: #ffffff;background-color: #343A40">نام</th>
        <th style="color: #ffffff;background-color: #343A40">نام خانوادگی</th>
        <th style="color: #ffffff;background-color: #343A40">کد ملی</th>
        <th style="color: #ffffff;background-color: #343A40">موبایل</th>
        <th style="color: #ffffff;background-color: #343A40">شروع(0000/00/00)</th>
        <th style="color: #ffffff;background-color: #343A40">پایان(0000/00/00)</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
