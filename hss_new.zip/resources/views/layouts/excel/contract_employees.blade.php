<table style="direction: rtl">
    <thead>
    <tr>
        <th style="color: #ffffff;background-color: #343A40">نام پرسنل</th>
        <th style="color: #ffffff;background-color: #343A40">کد ملی</th>
        <th style="color: #ffffff;background-color: #343A40">موبایل</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
