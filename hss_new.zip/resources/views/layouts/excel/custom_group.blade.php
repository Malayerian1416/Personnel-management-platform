<table style="direction: rtl">
    <thead>
    <tr>
        <th style="color: #ffffff;background-color: #343A40">
            کد ملی پرسنل
            <strong style="color: red">*</strong>
        </th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
