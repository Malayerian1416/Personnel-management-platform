<table style="direction: rtl">
    <thead>
    <tr>
        <th style="color: #ffffff;background-color: #343A40">
            کد ملی پرسنل
            <strong style="color: red">*</strong>
        </th>
        <th style="color: #ffffff;background-color: #343A40">
            دستمزد روزانه
        </th>
        <th style="color: #ffffff;background-color: #343A40">
            پایه سنوات(ماهانه)
        </th>
        <th style="color: #ffffff;background-color: #343A40">
            روزهای کارکرد
        </th>
        <th style="color: #ffffff;background-color: #343A40">
            گروه شغلی
        </th>
        <th style="color: #ffffff;background-color: #343A40">
            اولاد تحت تکفل
        </th>
        <th style="color: #ffffff;background-color: #343A40">
            مزایا(عنوان در این سطر و مقدار آن به ازای هر نفر در ردیف مربوطه مشخص گردد)
        </th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
